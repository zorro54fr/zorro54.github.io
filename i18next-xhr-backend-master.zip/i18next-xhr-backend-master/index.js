module.exports = require('./dist/commonjs/index.js').default;
